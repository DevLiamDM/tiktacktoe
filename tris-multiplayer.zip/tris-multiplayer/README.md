# Tris (Tic-Tac-Toe) con Ncurses

Un semplice gioco del tris da terminale, scritto in C, con interfaccia `ncurses`.

## 🔧 Requisiti

- Linux/macOS
- `gcc`
- Libreria `ncurses`

Installa `ncurses`:

```bash
sudo apt install libncurses5-dev libncursesw5-dev
```

## ▶️ Compilazione

```bash
make
./tris
```

## 🎮 Funzionalità

- Giocatore vs CPU (mosse casuali)
- Interfaccia a colori nel terminale
- Salvataggio log delle partite in `score.txt`

## 📄 File

- `main.c`: menu e flusso principale
- `logic.c/h`: logica del gioco
- `score.c/h`: salvataggio punteggi
- `Makefile`: build semplificata

---
