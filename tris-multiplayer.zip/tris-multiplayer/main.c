#include <ncurses.h>
#include <stdlib.h>
#include <time.h>
#include "logic.h"
#include "score.h"

void printMenu() {
    mvprintw(2, 2, "=== Tris Game ===");
    mvprintw(4, 4, "1. Gioca contro CPU");
    mvprintw(5, 4, "2. Esci");
    mvprintw(7, 2, "Scelta: ");
}

int main() {
    int choice;
    initscr();
    noecho();
    cbreak();
    keypad(stdscr, TRUE);

    do {
        clear();
        printMenu();
        refresh();
        scanw("%d", &choice);
        if (choice == 1) {
            clear();
            initGame();
            playGame();
            saveScore();
            getch();
        }
    } while (choice != 2);

    endwin();
    return 0;
}
