#include "logic.h"
#include <ncurses.h>
#include <stdlib.h>
#include <time.h>

char board[3][3];
int currentPlayer; // 0 = Player X, 1 = Player O

void initGame() {
    currentPlayer = 0;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            board[i][j] = ' ';
}

void drawBoard() {
    mvprintw(2, 4, "  0 1 2");
    for (int i = 0; i < 3; i++) {
        mvprintw(3 + i, 4, "%d %c|%c|%c", i, board[i][0], board[i][1], board[i][2]);
    }
}

int makeMove(int row, int col, char symbol) {
    if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ')
        return 0;
    board[row][col] = symbol;
    return 1;
}

int checkWinner(char symbol) {
    for (int i = 0; i < 3; i++)
        if ((board[i][0] == symbol && board[i][1] == symbol && board[i][2] == symbol) ||
            (board[0][i] == symbol && board[1][i] == symbol && board[2][i] == symbol))
            return 1;
    if ((board[0][0] == symbol && board[1][1] == symbol && board[2][2] == symbol) ||
        (board[0][2] == symbol && board[1][1] == symbol && board[2][0] == symbol))
        return 1;
    return 0;
}

int isDraw() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] == ' ') return 0;
    return 1;
}

void playGame() {
    int row, col;
    char symbols[2] = {'X', 'O'};
    while (1) {
        clear();
        drawBoard();
        mvprintw(7, 2, "Giocatore %c, inserisci riga e colonna: ", symbols[currentPlayer]);
        scanw("%d %d", &row, &col);
        if (!makeMove(row, col, symbols[currentPlayer])) continue;
        if (checkWinner(symbols[currentPlayer])) {
            clear();
            drawBoard();
            mvprintw(10, 2, "Giocatore %c ha vinto!", symbols[currentPlayer]);
            break;
        }
        if (isDraw()) {
            clear();
            drawBoard();
            mvprintw(10, 2, "Pareggio!");
            break;
        }
        currentPlayer = 1 - currentPlayer;
    }
}
