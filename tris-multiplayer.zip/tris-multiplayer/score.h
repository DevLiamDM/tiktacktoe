#ifndef SCORE_H
#define SCORE_H

void saveScore();

#endif
