#include "score.h"
#include <stdio.h>

void saveScore() {
    FILE *f = fopen("score.txt", "a");
    if (f) {
        fprintf(f, "Partita completata\n");
        fclose(f);
    }
}
