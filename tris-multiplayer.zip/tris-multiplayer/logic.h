#ifndef LOGIC_H
#define LOGIC_H

void initGame();
void drawBoard();
int makeMove(int row, int col, char symbol);
int checkWinner(char symbol);
int isDraw();
void cpuMove();
void playGame();

#endif
